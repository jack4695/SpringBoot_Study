package com.edu.springboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class B07dMybatisBoardApplication {

	public static void main(String[] args) {
		SpringApplication.run(B07dMybatisBoardApplication.class, args);
	}

}
